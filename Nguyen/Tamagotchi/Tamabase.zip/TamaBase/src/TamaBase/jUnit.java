package TamaBase;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;


public class jUnit {
	
	@Test
    public void test() {
		TamaBase yoshi=new TamaBase(10,10);
		assertEquals(4, yoshi.riceviCarezze(4));          
    
	}
}
	
