package TamaBase;

public class TamaBase {
	private static int maxSoddisfazione = 100;
	private static int sogliaSoddisfazione = 30;
	private static int minSoddisfazione = 0;
	private static int maxSaziet� = 100;
	private static int sogliaSaziet� = 30;
	private static int minSaziet� = 0;

	private int gradoSoddisfazione;
	private int gradoSaziet�;
	private boolean felicit�;
	private boolean morto;

	public TamaBase(int _gradoSoddisfazione, int _gradoSaziet�) {
		super();
		this.gradoSoddisfazione = _gradoSoddisfazione;
		this.gradoSaziet� = _gradoSaziet�;
		this.felicit� = isFelice();
		this.morto = isMorto();
	}

	public int riceviCarezze(int nCarezze) {
		if (nCarezze > maxSoddisfazione) {
			return -1;
		} else {
			gradoSoddisfazione += nCarezze;
			gradoSaziet� -= 5;
		}

		return 1;
	}
	
	
	

	public int riceviCibo(int nBiscotti) {
		if (nBiscotti > maxSaziet�) {
			return -1;
		} else {
			gradoSaziet� += nBiscotti;
			gradoSoddisfazione -= 5;
			
		}

		return 1;
	}
	public boolean isFelice() 
	{
		boolean felice=false;
		if(gradoSaziet�<sogliaSaziet� || gradoSoddisfazione<sogliaSoddisfazione) 
		{
			felice=false;
			return felice;
		}
		else 
		{
			felice=true;
		}
		return felice;
	}
	public boolean isMorto() 
	{
		boolean isMorto=false;
		if(gradoSaziet�<=0 || gradoSoddisfazione<=0 || gradoSaziet�>maxSaziet�) 
		{
			isMorto=true;
		}
		return isMorto;
	}

	public int getGradoSoddisfazione() {
		return gradoSoddisfazione;
	}

	public void setGradoSoddisfazione(int gradoSoddisfazione) {
		this.gradoSoddisfazione = gradoSoddisfazione;
	}

	public int getGradoSaziet�() {
		return gradoSaziet�;
	}

	public void setGradoSaziet�(int gradoSaziet�) {
		this.gradoSaziet� = gradoSaziet�;
	}

	public boolean isFelicit�() {
		return felicit�;
	}

	public void setFelicit�(boolean felicit�) {
		this.felicit� = felicit�;
	}

	public String toString() {
		String s;
		s = "Il grado di soddisfazione del Tamagotchi e' : " + this.gradoSoddisfazione;
		s += "\nIl grado di saziet� del Tamagotchi e' : " + this.gradoSaziet�;
		if(isMorto()==true) 
		{
			s+= "\n il tamagotchi e' morto ";
			return s;
		}
		if(isFelice()==true)
		{
			s += "\nIl Tamagotchi e' felice ";
		}else 
		{
			s += "\nIl Tamagotchi e' infelice ";
		}
		
		return s;

	}
}