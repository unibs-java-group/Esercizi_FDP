package TamaBase;

import it.unibs.fp.mylib.InputDati;
import java.util.Random;

public class TamaBaseMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//TamaBase t1 = new TamaBase(10, 10);
		//t1.riceviCarezze(3);
		//t1.riceviCibo(3);
		//System.out.print(t1.toString());
		int maxCarezze= 20;
		int  maxCibo = 10;
		TamaBase t1 = crea_Tamagotchi();
		Random generator = new Random();
		int controllo=0;
		int nCarezze,nBiscotti;
		do 
		{
			int opz;
			
			System.out.println("(1) Accarezza il Tamagotchi");
			System.out.println("(2) nutrisci il Tamagotchi");
			System.out.println("(3) controlla lo stato del Tamagotchi");
			System.out.println("(4) termina programma");
			opz=InputDati.leggiIntero("Inserire opzione");
			
			switch(opz) 
			{
				case 1:
					//nCarezze=InputDati.leggiIntero("Inserire il numero di carezza da dare (Max 20)",0,20);
					nCarezze=generator.nextInt(maxCarezze);
					t1.riceviCarezze(nCarezze);
					break;
				case 2:
					//nBiscotti=InputDati.leggiIntero("Inserire il numero di biscotti da dare (Max 20)",0,20);
					nBiscotti=generator.nextInt(maxCibo);
					t1.riceviCibo(nBiscotti);
					break;
				case 3:
					System.out.println(t1.toString());
					break;
				default:
					controllo=1;
			}
		}while(controllo!=1);
		System.out.println(" programma terminato correttamente");
	}

	public static TamaBase crea_Tamagotchi() {
		int gradoSo,gradoSa;
		gradoSo=InputDati.leggiIntero("Inserire Grado di soddisfazione di partenza",0,100);
		gradoSa=InputDati.leggiIntero("Inserire Grado di saziet� di partenza",0,100);
		TamaBase t1 = new TamaBase(gradoSo, gradoSa);
		return t1;
	}

}